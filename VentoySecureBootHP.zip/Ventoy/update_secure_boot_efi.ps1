# PowerShell script to update Ventoy's Secure Boot EFI with latest Microsoft-signed binary
# This addresses SBAT data issues that cause failures on HP and other devices

Write-Host "Updating Ventoy Secure Boot EFI..."

# Get the latest release from GitHub API
$apiUrl = "https://api.github.com/repos/ValdikSS/Super-UEFIinSecureBoot-Disk/releases/latest"
$response = Invoke-RestMethod -Uri $apiUrl
$asset = $response.assets | Where-Object { $_.name -like "*minimal*.zip" } | Select-Object -First 1

if (-not $asset) {
    Write-Host "Failed to find the minimal zip asset"
    exit 1
}

$downloadUrl = $asset.browser_download_url
$zipPath = "super_uefi_secure_boot.zip"

Write-Host "Downloading $downloadUrl..."

# Download the zip file
Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath

Write-Host "Extracting..."

# Extract the zip
Expand-Archive -Path $zipPath -DestinationPath .

# Find the img file
$imgFile = Get-ChildItem -Path . -Filter "*.img" | Select-Object -First 1

if (-not $imgFile) {
    Write-Host "No .img file found in the archive"
    exit 1
}

Write-Host "Found IMG file: $($imgFile.Name)"

# Mount the IMG file (requires admin rights)
$mountResult = Mount-DiskImage -ImagePath $imgFile.FullName -PassThru
$driveLetter = ($mountResult | Get-Volume).DriveLetter

if (-not $driveLetter) {
    Write-Host "Failed to mount IMG file"
    exit 1
}

Write-Host "Mounted at drive $driveLetter"

# Copy EFI files
$sourcePath = "${driveLetter}:\EFI\BOOT"
$destPath = "EFI\BOOT"

if (!(Test-Path $destPath)) {
    New-Item -ItemType Directory -Path $destPath -Force
}

if (Test-Path "$sourcePath\BOOTX64.EFI") {
    Copy-Item "$sourcePath\BOOTX64.EFI" $destPath -Force
    Write-Host "Copied BOOTX64.EFI"
}

if (Test-Path "$sourcePath\BOOTIA32.EFI") {
    Copy-Item "$sourcePath\BOOTIA32.EFI" $destPath -Force
    Write-Host "Copied BOOTIA32.EFI"
}

# Dismount
Dismount-DiskImage -ImagePath $imgFile.FullName

# Clean up
Remove-Item $zipPath
Remove-Item $imgFile.FullName

Write-Host "Secure Boot EFI updated successfully."
Write-Host "This should improve compatibility with HP devices and active Secure Boot."