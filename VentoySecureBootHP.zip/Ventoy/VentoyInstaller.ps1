#Requires -RunAsAdministrator

# Ventoy Auto-Installer with HP Secure Boot Support
# This script downloads Ventoy, updates EFI for Secure Boot and HP compatibility, and installs it on a USB drive

param(
    [string]$DriveLetter = ""
)

Write-Host "Ventoy Auto-Installer with HP Secure Boot Support" -ForegroundColor Green
Write-Host "=================================================" -ForegroundColor Green

# Function to download file
function Download-File {
    param([string]$Url, [string]$Output)
    Write-Host "Downloading $Url..."
    Invoke-WebRequest -Uri $Url -OutFile $Output
}

# Function to get latest Ventoy release
function Get-LatestVentoyUrl {
    $apiUrl = "https://api.github.com/repos/ventoy/Ventoy/releases/latest"
    $response = Invoke-RestMethod -Uri $apiUrl
    $asset = $response.assets | Where-Object { $_.name -like "ventoy-*-windows.zip" } | Select-Object -First 1
    return $asset.browser_download_url
}

# Download Ventoy
$ventoyUrl = Get-LatestVentoyUrl
$ventoyZip = "ventoy.zip"
Download-File -Url $ventoyUrl -Output $ventoyZip

# Extract Ventoy
Write-Host "Extracting Ventoy..."
Expand-Archive -Path $ventoyZip -DestinationPath "ventoy_temp" -Force

# Find Ventoy2Disk.exe
$ventoyExe = Get-ChildItem -Path "ventoy_temp" -Filter "Ventoy2Disk.exe" -Recurse | Select-Object -First 1
if (-not $ventoyExe) {
    Write-Host "Ventoy2Disk.exe not found!" -ForegroundColor Red
    exit 1
}

# Update EFI files
Write-Host "Updating EFI files for Secure Boot and HP compatibility..."
& ".\update_secure_boot_efi.ps1"

# Copy updated EFI to Ventoy directory
$efiSource = "EFI\BOOT"
$efiDest = "ventoy_temp\EFI\BOOT"
if (Test-Path $efiSource) {
    Copy-Item -Path "$efiSource\*" -Destination $efiDest -Force -Recurse
}

# Get drive letter if not provided
if (-not $DriveLetter) {
    Write-Host "Available drives:" -ForegroundColor Yellow
    Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 2 } | ForEach-Object {
        Write-Host "$($_.DeviceID) - $($_.VolumeName) ($([math]::Round($_.Size / 1GB, 2)) GB)"
    }
    $DriveLetter = Read-Host "Enter the drive letter of your USB drive (e.g., E)"
}

$drivePath = "${DriveLetter}:"
if (-not (Test-Path $drivePath)) {
    Write-Host "Drive $drivePath not found!" -ForegroundColor Red
    exit 1
}

# Confirm
$confirm = Read-Host "This will erase all data on drive $DriveLetter. Continue? (y/n)"
if ($confirm -ne 'y') {
    Write-Host "Installation cancelled."
    exit 0
}

# Install Ventoy
Write-Host "Installing Ventoy on drive $DriveLetter..."
$args = "/install", "/drive:$DriveLetter", "/secureboot"
& $ventoyExe.FullName $args

if ($LASTEXITCODE -eq 0) {
    Write-Host "Ventoy installed successfully!" -ForegroundColor Green
    Write-Host "For HP devices with Secure Boot, enroll the key/hash during first boot."
} else {
    Write-Host "Installation failed!" -ForegroundColor Red
}

# Cleanup
Remove-Item $ventoyZip -Force
Remove-Item "ventoy_temp" -Recurse -Force