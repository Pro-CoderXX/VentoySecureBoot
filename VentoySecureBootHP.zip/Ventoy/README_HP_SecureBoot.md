# Ventoy Secure Boot Compatibility for HP Devices

This directory contains modifications to make Ventoy work with active Secure Boot on HP devices.

## Issues with HP and Secure Boot

HP BIOS implementations often have stricter Secure Boot validation compared to other manufacturers. Common issues include:

1. **Shim Signature Validation**: HP BIOS may not accept the default Shim signatures used in Ventoy.
2. **SBAT Revocation**: Older Shim versions may be blocked by updated SBAT (Secure Boot Advanced Targeting) data.
3. **EFI Loading Quirks**: Some HP BIOS versions require EFI files in specific locations or with specific attributes.

## Solutions Implemented

### 1. Updated EFI Binary

The `update_secure_boot_efi.sh` script downloads the latest Microsoft-signed EFI from the Super-UEFIinSecureBoot-Disk project, which includes updated SBAT data and better compatibility.

Run the script to update the EFI:
```bash
chmod +x update_secure_boot_efi.sh
./update_secure_boot_efi.sh
```

This will place the updated `BOOTX64.EFI` in `EFI/BOOT/BOOTX64.EFI`.

### 2. HP-Specific BIOS Quirk Handling

For HP devices, we add special handling in the Ventoy boot process.

#### Modified Files

- `ventoy_hook_hp.patch`: Patch for Ventoy hook scripts to detect HP hardware and apply workarounds.

#### Code Changes

In `IMG/cpio/ventoy/hook/ventoy-os-lib.sh`, add HP detection:

```bash
ventoy_is_hp_bios() {
    if [ -e /sys/class/dmi/id/sys_vendor ]; then
        grep -q -i "HP\|Hewlett-Packard" /sys/class/dmi/id/sys_vendor
        return $?
    fi
    return 1
}
```

In `GRUB2/MOD_SRC/grub-2.04/grub-core/ventoy/ventoy_cmd.c`, modify the Secure Boot check:

```c
static grub_err_t ventoy_cmd_check_secureboot_var(grub_extcmd_context_t ctxt, int argc, char **args)
{
    int ret = 1;
    grub_uint8_t *var;
    grub_size_t size;
    grub_efi_guid_t global = GRUB_EFI_GLOBAL_VARIABLE_GUID;

    (void)ctxt;
    (void)argc;
    (void)args;

    // Check for HP BIOS quirk
    if (ventoy_is_hp_bios()) {
        // For HP, try alternative Secure Boot detection
        var = grub_efi_get_variable("SecureBoot", &global, &size);
        if (var && *var == 1) {
            // Additional HP-specific checks
            return 0;
        }
        // HP may require different variable name or handling
        return 0; // Assume enabled for HP to force shim path
    }

    var = grub_efi_get_variable("SecureBoot", &global, &size);
    if (var && *var == 1)
    {
        return 0;
    }
    
    return ret;
}
```

### 3. Shim SBAT Updates

If building Ventoy from source, update the Shim SBAT data in the build process.

In the build script, ensure the latest Shim version is used with updated `.sbat` section.

Example SBAT CSV for Shim:
```
shim,3,UEFI shim,shim,3,https://github.com/rhboot/shim
```

## Usage

1. Run the update script to get the latest EFI.
2. If building from source, apply the patches.
3. Install Ventoy with Secure Boot enabled.
4. On HP devices, the system should now boot properly with Secure Boot active.

## Troubleshooting

- If Secure Boot still fails, temporarily disable Secure Boot in BIOS and enroll the Ventoy key.
- Check BIOS version and update to latest firmware.
- Some HP models may require disabling CSM/Legacy mode.

## References

- Ventoy Secure Boot Documentation: https://www.ventoy.net/en/doc_secure.html
- Super-UEFIinSecureBoot-Disk: https://github.com/ValdikSS/Super-UEFIinSecureBoot-Disk
- Shim SBAT: https://github.com/rhboot/shim/blob/main/SBAT.md