#!/bin/bash

# Script to download and extract the latest Super-UEFIinSecureBoot-Disk EFI for Ventoy Secure Boot compatibility
# This addresses issues with HP devices where older versions may not work with active Secure Boot

set -e

echo "Downloading latest Super-UEFIinSecureBoot-Disk..."

# Get the latest release URL from GitHub API
LATEST_URL=$(curl -s https://api.github.com/repos/ValdikSS/Super-UEFIinSecureBoot-Disk/releases/latest | grep "browser_download_url.*minimal.*zip" | cut -d '"' -f 4)

if [ -z "$LATEST_URL" ]; then
    echo "Failed to get latest release URL"
    exit 1
fi

echo "Latest URL: $LATEST_URL"

# Download the zip file
wget -O super_uefi_secure_boot.zip "$LATEST_URL"

echo "Extracting..."

# Extract the zip
unzip super_uefi_secure_boot.zip

# Find the img file
IMG_FILE=$(find . -name "*.img" | head -1)

if [ -z "$IMG_FILE" ]; then
    echo "No .img file found"
    exit 1
fi

echo "Found IMG file: $IMG_FILE"

# Extract EFI from img using 7zip or similar
if command -v 7z >/dev/null 2>&1; then
    7z x "$IMG_FILE" -oextracted
elif command -v p7zip >/dev/null 2>&1; then
    p7zip -d "$IMG_FILE" extracted/
else
    echo "7zip or p7zip not found. Please install and try again."
    exit 1
fi

# Find the EFI file
EFI_FILE=$(find extracted -name "BOOTX64.EFI" | head -1)

if [ -z "$EFI_FILE" ]; then
    echo "BOOTX64.EFI not found"
    exit 1
fi

echo "Found EFI: $EFI_FILE"

# Copy to Ventoy directory
mkdir -p EFI/BOOT
cp "$EFI_FILE" EFI/BOOT/BOOTX64.EFI

echo "Updated EFI/BOOT/BOOTX64.EFI"

# Cleanup
rm -rf super_uefi_secure_boot.zip extracted

echo "Done. This updated EFI may improve Secure Boot compatibility with HP devices."