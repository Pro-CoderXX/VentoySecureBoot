#Requires -RunAsAdministrator

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create main form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Ventoy Installer - HP Secure Boot Edition"
$form.Size = New-Object System.Drawing.Size(500, 400)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)

# Title label
$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "Ventoy Auto-Installer with HP Secure Boot Support"
$titleLabel.Font = New-Object System.Drawing.Font("Arial", 14, [System.Drawing.FontStyle]::Bold)
$titleLabel.Size = New-Object System.Drawing.Size(450, 40)
$titleLabel.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($titleLabel)

# Status label
$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Ready to install Ventoy..."
$statusLabel.Size = New-Object System.Drawing.Size(450, 30)
$statusLabel.Location = New-Object System.Drawing.Point(20, 70)
$form.Controls.Add($statusLabel)

# Drive selection
$driveLabel = New-Object System.Windows.Forms.Label
$driveLabel.Text = "Select USB Drive:"
$driveLabel.Size = New-Object System.Drawing.Size(120, 20)
$driveLabel.Location = New-Object System.Drawing.Point(20, 110)
$form.Controls.Add($driveLabel)

$driveCombo = New-Object System.Windows.Forms.ComboBox
$driveCombo.Size = New-Object System.Drawing.Size(200, 20)
$driveCombo.Location = New-Object System.Drawing.Point(140, 110)
$driveCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$form.Controls.Add($driveCombo)

# Refresh drives button
$refreshButton = New-Object System.Windows.Forms.Button
$refreshButton.Text = "Refresh Drives"
$refreshButton.Size = New-Object System.Drawing.Size(100, 30)
$refreshButton.Location = New-Object System.Drawing.Point(350, 105)
$form.Controls.Add($refreshButton)

# Progress bar
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Size = New-Object System.Drawing.Size(450, 20)
$progressBar.Location = New-Object System.Drawing.Point(20, 150)
$form.Controls.Add($progressBar)

# Install button
$installButton = New-Object System.Windows.Forms.Button
$installButton.Text = "Install Ventoy"
$installButton.Size = New-Object System.Drawing.Size(120, 40)
$installButton.Location = New-Object System.Drawing.Point(190, 180)
$installButton.BackColor = [System.Drawing.Color]::FromArgb(0, 123, 255)
$installButton.ForeColor = [System.Drawing.Color]::White
$installButton.Font = New-Object System.Drawing.Font("Arial", 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($installButton)

# Log textbox
$logTextBox = New-Object System.Windows.Forms.TextBox
$logTextBox.Multiline = $true
$logTextBox.ScrollBars = "Vertical"
$logTextBox.Size = New-Object System.Drawing.Size(450, 120)
$logTextBox.Location = New-Object System.Drawing.Point(20, 240)
$logTextBox.ReadOnly = $true
$form.Controls.Add($logTextBox)

# Functions
function Update-Status {
    param([string]$message)
    $statusLabel.Text = $message
    $logTextBox.AppendText("$(Get-Date -Format 'HH:mm:ss'): $message`r`n")
    [System.Windows.Forms.Application]::DoEvents()
}

function Refresh-Drives {
    $driveCombo.Items.Clear()
    $drives = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 2 }
    foreach ($drive in $drives) {
        $sizeGB = [math]::Round($drive.Size / 1GB, 2)
        $driveCombo.Items.Add("$($drive.DeviceID) - $($drive.VolumeName) ($sizeGB GB)")
    }
    if ($driveCombo.Items.Count -gt 0) {
        $driveCombo.SelectedIndex = 0
    }
}

function Update-SecureBootEFI {
    Update-Status "Updating EFI files for Secure Boot and HP compatibility..."
    
    # Get the latest release from GitHub API
    $apiUrl = "https://api.github.com/repos/ValdikSS/Super-UEFIinSecureBoot-Disk/releases/latest"
    $response = Invoke-RestMethod -Uri $apiUrl
    $asset = $response.assets | Where-Object { $_.name -like "*minimal*.zip" } | Select-Object -First 1

    if (-not $asset) {
        throw "Failed to find the minimal zip asset"
    }

    $downloadUrl = $asset.browser_download_url
    $zipPath = "$env:TEMP\super_uefi_secure_boot.zip"

    # Download the zip file
    Invoke-WebRequest -Uri $downloadUrl -OutFile $zipPath

    # Extract the zip
    $extractPath = "$env:TEMP\super_uefi_extract"
    if (Test-Path $extractPath) { Remove-Item $extractPath -Recurse -Force }
    Expand-Archive -Path $zipPath -DestinationPath $extractPath

    # Find the img file
    $imgFile = Get-ChildItem -Path $extractPath -Filter "*.img" | Select-Object -First 1

    if (-not $imgFile) {
        throw "No .img file found in the archive"
    }

    # Mount the IMG file (requires admin rights)
    $mountResult = Mount-DiskImage -ImagePath $imgFile.FullName -PassThru
    $driveLetter = ($mountResult | Get-Volume).DriveLetter

    if (-not $driveLetter) {
        throw "Failed to mount IMG file"
    }

    # Copy EFI files
    $sourcePath = "${driveLetter}:\EFI\BOOT"
    $destPath = "$env:TEMP\EFI\BOOT"

    if (!(Test-Path $destPath)) {
        New-Item -ItemType Directory -Path $destPath -Force
    }

    if (Test-Path "$sourcePath\BOOTX64.EFI") {
        Copy-Item "$sourcePath\BOOTX64.EFI" $destPath -Force
    }

    if (Test-Path "$sourcePath\BOOTIA32.EFI") {
        Copy-Item "$sourcePath\BOOTIA32.EFI" $destPath -Force
    }

    # Dismount
    Dismount-DiskImage -ImagePath $imgFile.FullName

    # Clean up
    Remove-Item $zipPath -Force
    Remove-Item $extractPath -Recurse -Force
}

function Get-LatestVentoyUrl {
    $apiUrl = "https://api.github.com/repos/ventoy/Ventoy/releases/latest"
    $response = Invoke-RestMethod -Uri $apiUrl
    $asset = $response.assets | Where-Object { $_.name -like "ventoy-*-windows.zip" } | Select-Object -First 1
    return $asset.browser_download_url
}

function Install-Ventoy {
    $progressBar.Value = 10
    Update-Status "Getting latest Ventoy version..."

    try {
        # Download Ventoy
        $ventoyUrl = Get-LatestVentoyUrl
        $ventoyZip = "$env:TEMP\ventoy.zip"
        Download-File -Url $ventoyUrl -Output $ventoyZip
        $progressBar.Value = 30

        # Extract Ventoy
        Update-Status "Extracting Ventoy..."
        $extractPath = "$env:TEMP\ventoy_temp"
        if (Test-Path $extractPath) { Remove-Item $extractPath -Recurse -Force }
        Expand-Archive -Path $ventoyZip -DestinationPath $extractPath -Force
        $progressBar.Value = 50

        # Find Ventoy2Disk.exe
        $ventoyExe = Get-ChildItem -Path $extractPath -Filter "Ventoy2Disk.exe" -Recurse | Select-Object -First 1
        if (-not $ventoyExe) {
            throw "Ventoy2Disk.exe not found!"
        }

        # Update EFI files
        Update-SecureBootEFI
        $progressBar.Value = 70

        # Copy updated EFI to Ventoy directory
        $efiSource = "$env:TEMP\EFI\BOOT"
        $efiDest = "$extractPath\EFI\BOOT"
        if (Test-Path $efiSource) {
            Copy-Item -Path "$efiSource\*" -Destination $efiDest -Force -Recurse
        }

        # Get selected drive
        $selectedItem = $driveCombo.SelectedItem
        if (-not $selectedItem) {
            throw "No drive selected!"
        }
        $driveLetter = $selectedItem.Split(' ')[0].TrimEnd(':')

        # Confirm installation
        $result = [System.Windows.Forms.MessageBox]::Show(
            "This will erase all data on drive $driveLetter. Continue?",
            "Confirm Installation",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )

        if ($result -eq [System.Windows.Forms.DialogResult]::No) {
            Update-Status "Installation cancelled."
            return
        }

        # Install Ventoy
        Update-Status "Installing Ventoy on drive $driveLetter..."
        $args = "/install", "/drive:$driveLetter", "/secureboot"
        & $ventoyExe.FullName $args
        $progressBar.Value = 90

        if ($LASTEXITCODE -eq 0) {
            $progressBar.Value = 100
            Update-Status "Ventoy installed successfully!"
            [System.Windows.Forms.MessageBox]::Show(
                "Ventoy has been installed successfully!`n`nFor HP devices with Secure Boot, enroll the key/hash during first boot.",
                "Installation Complete",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            )
        } else {
            throw "Installation failed!"
        }

    } catch {
        Update-Status "Error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show(
            "Installation failed: $($_.Exception.Message)",
            "Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
    } finally {
        # Cleanup
        if (Test-Path "$env:TEMP\ventoy.zip") { Remove-Item "$env:TEMP\ventoy.zip" -Force }
        if (Test-Path "$env:TEMP\ventoy_temp") { Remove-Item "$env:TEMP\ventoy_temp" -Recurse -Force }
    }
}

# Event handlers
$refreshButton.Add_Click({ Refresh-Drives })
$installButton.Add_Click({ Install-Ventoy })

# Initialize
Refresh-Drives
Update-Status "Ready to install Ventoy..."

# Show form
$form.ShowDialog()